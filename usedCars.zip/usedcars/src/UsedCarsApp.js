import React, {Component} from 'react';
import './App.css';
import UsedCarsView from './usedcarsview/UsedCarsView';
import CarInput from './carinput/CarInput';

var carsArray = [
    {id: 0, year: 1997, registered: 867621600000, make: 'Ford', model: 'E350', description: 'ac,abs, moon', price: 3000}
    , {id: 1, year: 1999, registered: 945212400000, make: 'Chevy', model: 'Venture', description: 'None', price: 4900}
    , {id: 2,year: 2000, registered: 953766000000, make: 'Chevy', model: 'Venture', description: '', price: 5000}
    , {id: 3,year: 1996,registered: 844380000000,make: 'Jeep',model: 'GrandCherokee',description: 'Air, moon roof, loaded',price: 4799}
    , {id: 4,year: 2012,registered: 844380000000,make: 'VW',model: 'Up',description: 'Air, moon roof, loaded',price: 2799}
    , {id: 5,year: 2015,registered: 844380000000,make: 'Fiat',model: 'Panda',description: 'Breaks, Seats, Steering wheel',price: 1799}
];

class UsedCarsApp extends Component{

    constructor(props){
        super(props);
        //format the date string to something usefull in each car object
        carsArray.forEach((car)=>{
            car.registered =(new Date(car.registered)).toISOString().slice(0, 10);
        });
        //Set State object
        this.state = { cars: carsArray};
        //Bind the 'this' reference to each method in this class
        this.deleteCar = this.deleteCar.bind(this);
        this.grabCar = this.grabCar.bind(this);
        this.submitCar = this.submitCar.bind(this);
    }

    //This method is run from the UsedCarsView (the delete button)
    deleteCar = function(target){
      var cars = this.state.cars;
      var id = parseInt(target.id, 10); //Radix 10 to show decimal
      var index;
      for(var i = 0; i < cars.length; i++)
      {
        if(cars[i].id === id)
        {
          index = i;
        }
      }
      cars.splice(index, 1);
      this.forceUpdate();
      }

    //This method is run from the UsedCarsView (edit buttons) in order to fill the CarInput component with the appropriate data.
    grabCar = function(target){
      var selectedCar;
      var targetId = parseInt(target.id, 10); //Radix 10 to show decimal
      this.state.cars.forEach(car => {
        if (car.id === targetId)
        {
          selectedCar = car;
        }
      });
      this.setState({car: selectedCar}); //Det her er retarderet
      this.forceUpdate();
    }

    //This method is run from the CarInput Component with the data from the user form.
    submitCar = function(newCar){
      var cars = this.state.cars;
      var carExists = false;
      for(var i = 0; i < cars.length; i++)
      {
        if (newCar.id !== 0)
        {
          carExists = true;
        }
        i++;
      }
      if(carExists)
      {
        cars[newCar.id] = newCar;
      }
      else
      {
        newCar.id = this.getHighestID(cars) + 1;
        if(newCar.year === 0)
        {
          newCar.year = 2016;
        }
        cars.push(newCar);
      }
      this.forceUpdate();
    }

    render(){
        document.title = "Used Cars App";
        const car = this.state.car;
        return(
        <div id="containerDiv">
            <UsedCarsView cars={this.state.cars} delete={this.deleteCar} edit={this.grabCar}/>
            <CarInput car={car} submit={this.submitCar}/>
        </div>
            );
    }

    getHighestID(arr){
        var highest = 0;
        arr.forEach(car=>{
            if(car.id > highest){
                highest = car.id;
            }
        });
        return highest;
    }
}


export default UsedCarsApp;
