import React from 'react';
import ReactDOM from 'react-dom';
import {Router, Route, IndexRoute, hashHistory} from 'react-router';
import App from './UsedCarsApp';
import UsedCarsView from './usedcarsview/UsedCarsView';
import Layout from './Layout';
import CarInput from './carinput/CarInput';
import './index.css';

ReactDOM.render(
  <Router history={hashHistory}>
  <Route path='/' component={Layout}>
  <IndexRoute component={App}></IndexRoute>
  <Route path='add' component={CarInput}></Route>
  <Route path='home' component={App}></Route>
  <Route path='usedview' component={UsedCarsView}></Route>



  </Route>
  </Router>,
  document.getElementById('root')
);
